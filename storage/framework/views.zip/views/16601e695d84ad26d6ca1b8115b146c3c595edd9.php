<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('page_title'); ?></title>



    <script src="<?php echo e(asset('assets/js/general.js')); ?>"></script>


</head>

<body>


    


</body>

</html>
<?php /**PATH C:\xampp\htdocs\lentoria-frontend\resources\views\layouts\app.blade.php ENDPATH**/ ?>