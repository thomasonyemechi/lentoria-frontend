<?php $__env->startSection('page_title'); ?>
    Course | <?php echo e($slug); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_content'); ?>
    <div class="pt-5 pb-5">
        <div class="container">

            <?php echo $__env->make('instructor.course_name', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="row mt-0 mt-md-4">
                <div class="col-lg-3 col-md-4 col-12">
                    <?php echo $__env->make('instructor.side', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>

                <div class="col-lg-9 col-md-8 col-12">
                    <div class="card mb-4">
                        <div class="card-header">
                            <h3 class="mb-0">Intended learners</h3>
                        </div>
                        <div class="card-body">
                            <p>
                                The following descriptions will be publicly visible on your Course Landing Page and will
                                have a direct impact on your
                                course performance.
                                These descriptions will help learners decide if your course is right for them.
                            </p>
                            <form id="updateLearners">
                                <div class="mb-3">
                                    <label for="courseTitle" class="form-label"><b>What will students learn in your
                                            course?</b></label>
                                    <p>You must enter at least 4 learning objectives or outcomes that learners can expect to
                                        achieve after completing your course.</p>
                                    <input class="form-control what_you_will_learn mb-2" type="text"
                                        placeholder="Example: Define the roles and responsibilities of a project manager"
                                        maxlength="160" />
                                    <input class="form-control what_you_will_learn mb-2" type="text"
                                        placeholder="Example: Estimate project timelines and budgets" maxlength="160" />
                                    <input class="form-control what_you_will_learn mb-2" type="text"
                                        placeholder="Example: Identify and manage project risks" maxlength="160" />
                                    <input class="form-control what_you_will_learn mb-2" type="text"
                                        placeholder="Example: Complete a case study to manage a project from conception to completion"
                                        maxlength="160" />
                                    <a href="javascript:;" class="mt-3 add_input" data-class="what_you_will_learn">
                                        <b> <i class="fe fe-plus"></i> Add More To your Response</b>
                                    </a>
                                </div>

                                <div class="mb-3">
                                    <label for="courseTitle" class="form-label"><b>What are the requirements or
                                            prerequisites for taking your course?</b></label>
                                    <p>List the required skills, experience, tools or equipment learners should have prior
                                        to taking your course.
                                        If there are no requirements, use this space as an opportunity to lower the barrier
                                        for beginners.</p>
                                    <input class="form-control requirements mb-2" type="text"
                                        placeholder="Example: No programming experience needed. You will learn everything you need to know"
                                        maxlength="160" />
                                    <a href="javascript:;" class="mt-3 add_input" data-class="requirements">
                                        <b> <i class="fe fe-plus"></i> Add More To your Response</b>
                                    </a>
                                </div>

                                <div class="mb-3">
                                    <label for="courseTitle" class="form-label"><b>Who is this course for?</b></label>
                                    <p>Write a clear description of the intended learners for your course who will find your
                                        course content valuable.
                                        This will help you attract the right learners to your course.</p>
                                    <input class="form-control learners mb-2" type="text"
                                        placeholder="Example: Beginner Python developers curious about data science"
                                        maxlength="160" />
                                    <a href="javascript:;" class="mt-3 add_input" data-class="learners">
                                        <b> <i class="fe fe-plus"></i> Add More To your Response</b>
                                    </a>
                                </div>

                                <div class="mb-3">
                                    <label for="purposeTitle" class="form-label"><b>Purpose Of taking this
                                            course</b></label>
                                    <p></p>
                                    <input class="form-control purpose mb-2" type="text"
                                        placeholder="Purpose Of taking this course?" maxlength="160" />
                                    <a href="javascript:;" class="mt-3 add_input" data-class="purpose">
                                        <b> <i class="fe fe-plus"></i> Add More To your Response</b>
                                    </a>
                                </div>

                                <div class="mb-3">
                                    <label for="purposeTitle" class="form-label"><b>Job Opportunities</b></label>
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.textarea','data' => ['id' => 'opportunities','name' => 'opportunities']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'opportunities','name' => 'opportunities']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                </div>

                                <input type="hidden" name="course_id">
                                <div class="d-flex justify-content-end mt-3">
                                    <button type="submit" class="updateLearners btn btn-success">Save
                                        Answers</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        $(function() {


            $('body').on('click', '.updateLearners', function(e) {
                e.preventDefault();
                form = $('#updateLearners'); ///wywl == what you will learn
                bt = $(".updateLearners");

                id = $(form).find('input[name="course_id"]').val()

                wywls = $(form).find('.what_you_will_learn');
                jo = opportunities.getData();
                new_wywl = [];
                wywls.map(len => {
                    len = wywls[len];
                    if (len.value) {
                        new_wywl.push(len.value)
                    }
                })


                requirements = $(form).find('.requirements');
                new_req = []
                requirements.map(req => {
                    req = requirements[req];
                    if (req.value) {
                        new_req.push(req.value)
                    }
                })


                learners = $(form).find('.learners');
                new_len = []
                learners.map(le => {
                    le = learners[le];
                    if (le.value) {
                        new_len.push(le.value)
                    }
                })

                purpose = $(form).find('.purpose');
                new_pur = []
                purpose.map(pu => {
                    pu = purpose[pu];
                    if (pu.value) {
                        new_pur.push(pu.value)
                    }
                })

                $.ajax({
                    method: 'post',
                    url: api_url + 'admin/course_update_info',
                    data: {
                        course_id: id,
                        what_you_will_learn: new_wywl,
                        course_requirement: new_req,
                        course_audience: new_len,
                        purpose: new_pur,
                        opportunities: jo,
                    },
                    beforeSend: () => {
                        btn(bt, '', 'before')
                    }
                }).done(function(res) {
                    console.log(res);
                    btn(bt, 'Save Answers', 'after')
                    salat(res.message);
                }).fail(function(res) {
                    console.log(res);
                    concatError(res.responseJSON);
                    btn(bt, 'Save Answers', 'after')
                })

            })

            $('body').on('click', '.add_input', function() {
                cla = $(this).data('class');
                obj = $(`.${cla}`)
                last = obj[obj.length - 1];
                if (last.value == '' || last.value == null) {
                    return;
                }
                $(`<input class="form-control ${cla} mb-2" type="text" placeholder="Add more to your response" maxlength="160" />`)
                    .insertAfter(last);
            })



        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.instructor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lentoria-frontend\resources\views\instructor\learners.blade.php ENDPATH**/ ?>