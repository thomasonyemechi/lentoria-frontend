<style>
    .ck-editor__editable_inline {
        min-height: 80px;
    }
</style>

<?php foreach($attributes->onlyProps(['id', 'name', 'type' => 0]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['id', 'name', 'type' => 0]); ?>
<?php foreach (array_filter((['id', 'name', 'type' => 0]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<textarea class="form-control" id="<?php echo e($id); ?>" type="<?php echo e($type); ?>" name="<?php echo e($name); ?>" rows="3" style="resize: none"></textarea>

<script>
    $(function() {
        if (<?php echo \Illuminate\Support\Js::from($type)->toHtml() ?> == 0) {
            ClassicEditor
                .create(document.querySelector('#<?php echo e($id); ?>'), {
                    toolbar: ['heading', '|', 'bold', 'italic', 'link', 'bulletedList', 'numberedList',
                        'blockQuote'
                    ],
                    heading: {
                        options: [{
                                model: 'paragraph',
                                title: 'Paragraph',
                                class: 'ck-heading_paragraph'
                            },
                            {
                                model: 'heading1',
                                view: 'h1',
                                title: 'Heading 1',
                                class: 'ck-heading_heading1'
                            },
                            {
                                model: 'heading2',
                                view: 'h2',
                                title: 'Heading 2',
                                class: 'ck-heading_heading2'
                            },
                            {
                                model: 'heading3',
                                view: 'h3',
                                title: 'Heading 3',
                                class: 'ck-heading_heading3'
                            }
                        ]
                    }
                }).then(editor => {
                    window.editor = editor;
                    <?php echo e($name); ?> = editor;
                }).catch(error => {
                    console.log(error);
                });
        } else if (<?php echo \Illuminate\Support\Js::from($type)->toHtml() ?> == 1) {
            ClassicEditor
                .create(document.querySelector('#<?php echo e($id); ?>'), {
                    toolbar: ['bold', 'italic'],
                    heading: {
                        options: [{
                            model: 'paragraph',
                            title: 'Paragraph',
                            class: 'ck-heading_paragraph'
                        }]
                    }
                }).then(editor => {
                    window.editor = editor;
                    <?php echo e($name); ?> = editor;
                }).catch(error => {
                    console.log(error);
                });
        }


    })
</script>
<?php /**PATH C:\xampp\htdocs\lentoria-frontend\resources\views\components\textarea.blade.php ENDPATH**/ ?>