<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('page_title'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('assets/chat_assets/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/chat_assets/plugins/intltelinput/css/intlTelInput.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/chat_assets/plugins/intltelinput/css/demo.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/chat_assets/plugins/fontawesome/css/fontawesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/chat_assets/plugins/fontawesome/css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/chat_assets/plugins/mcustomscroll/jquery.mCustomScrollbar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/chat_assets/plugins/swiper/swiper.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/chat_assets/plugins/fancybox/css/jquery.fancybox.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/chat_assets/css/app.css')); ?>">
    <script src="<?php echo e(asset('assets/chat_assets/js/jquery-3.6.0.min.js')); ?>"></script>
</head>

<body>
    <?php echo $__env->make('layouts.alert_top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('page_content'); ?>

    <script src="<?php echo e(asset('assets/chat_assets/plugins/intltelinput/js/intlTelInput.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/chat_assets/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/chat_assets/js/jquery.nicescroll.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/chat_assets/plugins/mcustomscroll/jquery.mCustomScrollbar.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/chat_assets/plugins/slimscroll/jquery.slimscroll.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/chat_assets/plugins/swiper/swiper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/chat_assets/js/jquery-ui.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/chat_assets/plugins/fancybox/js/jquery.fancybox.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/chat_assets/js/script.js')); ?>"></script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\lentoria-frontend\resources\views\layouts\virtual_class.blade.php ENDPATH**/ ?>