<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('page_title'); ?></title>
    <link rel="icon" href="<?php echo e(asset('assets/images/logo2.png')); ?>" />
    <link href="<?php echo e(asset('assets/fonts/feather/feather.css')); ?>" rel="stylesheet" />
    <link href="https://vjs.zencdn.net/7.20.2/video-js.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
    <!-- Fantasy -->
    <link href="https://unpkg.com/@videojs/themes@1/dist/fantasy/index.css" rel="stylesheet">
    <link href="<?php echo e(asset('assets/libs/bootstrap-icons/font/bootstrap-icons.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/libs/dragula/dist/dragula.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/libs/%40mdi/font/css/materialdesignicons.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/libs/prismjs/themes/prism.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/libs/auxiliary-rater/lib/style.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/libs/magnific-popup/dist/magnific-popup.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('assets/libs/bootstrap-select/dist/css/bootstrap-select.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/libs/tiny-slider/dist/tiny-slider.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/libs/tippy.js/dist/tippy.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('assets/cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.css')); ?>">
    <script src="<?php echo e(asset('assets/libs/jquery/dist/jquery.min.js')); ?>"></script>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/theme.min.css')); ?>">
    <link href="<?php echo e(asset('assets/libs/bootstrap_file_input/css/fileinput.min.css')); ?>" media="all" rel="stylesheet"
        type="text/css" />
    <link href="<?php echo e(asset('assets/libs/bootstrap_file_input/explorer/theme.min.css')); ?>" media="all" rel="stylesheet"
        type="text/css" />
    <style>
        .animated-background {
            animation-duration: 1.25s;
            animation-fill-mode: forwards;
            animation-iteration-count: infinite;
            animation-name: placeHolderShimmer;
            animation-timing-function: linear;
            background: #F6F6F6;
            background: linear-gradient(to right, #F6F6F6 8%, #F0F0F0 18%, #F6F6F6 33%);
            background-size: 800px 104px;
            height: 96px;
            position: relative;
        }

        .text {
            margin-left: 20px
        }

        .text-line {
            height: 20px;
            width: 100px;
            @ .animated-background;
        }

        .vstack {
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex;
            -webkit-box-flex: 1;
            -ms-flex: 1 1 auto;
            flex: 1 1 auto;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -ms-flex-direction: column;
            flex-direction: column;
            -ms-flex-item-align: stretch;
            align-self: stretch;
        }

        .gap-2 {
            gap: 0.5rem !important;
        }
    </style>
    <script src="<?php echo e(asset('assets/js/general.js')); ?>"></script>

</head>

<body>

    <div class="littleAlert"></div>
    <?php echo $__env->make('layouts.alert_top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->renderUnless(request()->routeIs('instructor.course_review') || request()->routeIs('checkout_success'),
        'layouts.nav',
        ['status' => 'complete'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>

    <?php echo $__env->yieldContent('page_content'); ?>

    <?php echo $__env->renderUnless(request()->routeIs('instructor.course_review'), 'layouts.footer', ['status' => 'complete'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>

    
    <script>
        window.HELP_IMPROVE_VIDEOJS = false;
    </script>
    <script src="<?php echo e(asset('assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/jquery-slimscroll/jquery.slimscroll.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/magnific-popup/dist/jquery.magnific-popup.min.js')); ?>"></script>
    <script src="https://vjs.zencdn.net/7.20.2/video.min.js"></script>
    <script src="<?php echo e(asset('assets/libs/odometer/odometer.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/inputmask/dist/jquery.inputmask.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/file-upload-with-preview/dist/file-upload-with-preview.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/dragula/dist/dragula.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/bootstrap_file_input/js/plugins/buffer.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/bootstrap_file_input/js/plugins/filetype.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/bootstrap_file_input/js/fileinput.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/bootstrap_file_input/bs5/theme.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/bs-stepper/dist/js/bs-stepper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/jQuery.print/jQuery.print.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/prismjs/prism.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/auxiliary-rater/index.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/prismjs/components/prism-scss.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/tiny-slider/dist/min/tiny-slider.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/%40popperjs/core/dist/umd/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/tippy.js/dist/tippy-bundle.umd.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/cdnjs.cloudflare.com/ajax/libs/clipboard.js/1.5.12/clipboard.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/theme.min.js')); ?>"></script>
    <script src="https://cdn.ckeditor.com/ckeditor5/35.0.1/classic/ckeditor.js"></script>
</body>

</html>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\lentoria-frontend\resources\views\layouts\instructor.blade.php ENDPATH**/ ?>