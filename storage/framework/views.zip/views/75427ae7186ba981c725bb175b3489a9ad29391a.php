<?php foreach($attributes->onlyProps(['id', 'type' => 'add']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['id', 'type' => 'add']); ?>
<?php foreach (array_filter((['id', 'type' => 'add']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="card mb-4 bg-light-secondary d-none addseccard" id=<?php echo e($id); ?> type=<?php echo e($type); ?>>
    <div class="my-4 mx-2">
        <form>
            <div class="row mb-3">
                <div class="col-lg-2 mt-3 col-md-4 col-12">
                    <h5 class="text-bold fw-bolder">New Section:</h5>
                </div>
                <div class="col-lg-10 col-md-8 col-12">
                    <input type="text" name="title" class="form-control mb-1" placeholder="Enter a title">
                </div>
            </div>
            <div class="row mb-1">
                <div class="col-lg-2 col-md-4 col-12">
                </div>
                <div class="col-lg-10 col-md-8 col-12">
                    <label for="" class="text-bold fw-semi-bold text-dark">What will
                        Students Learn in this course</label>
                    <input type="text" name="purpose" class="form-control mb-2"
                        placeholder="Enter a learning objective">
                </div>
            </div>
            <div class="d-flex justify-content-end">
                <p class="pt-3 me-3 fw-semi-bold text-bold closecard"><a href="javascript:void(0)">Cancel</a></p>
                <button type="submit" class="btn btn-primary btn-block btn-xs">Add
                    Section</button>
            </div>
        </form>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\lentoria-frontend\resources\views\components\add-section-card.blade.php ENDPATH**/ ?>