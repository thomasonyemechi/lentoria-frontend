<?php if(Session::has('success')): ?>
    <script type="text/javascript">
        setTimeout(function() {
            $("#refresh").fadeOut(1000);
        }, 3000);
    </script>
    <div id="refresh" class="alert bg-success alert-dismissible"  style="position:fixed; top:55px; right:15px; z-index:999999999999999999">
        <i class="icon text-white">  <?php echo Session::get('success'); ?></i>
    </div>
<?php endif; ?>

<?php if(session::has('error')): ?>
    <script type="text/javascript">
        setTimeout(function() {
            $("#refresh").fadeOut(1000);
        }, 3000);
    </script>
    <div id="refresh" class="alert bg-danger" style="position:fixed; top:55px; right:15px; z-index:999999999999999999">
        <i class="icon text-white">  <?php echo session::get('error'); ?>  </i>
    </div>
<?php endif; ?>


<script>
    $.ajaxSetup({
        headers: {
            'Authorization': `Bearer <?php echo e(access_token()); ?>`
        }
    });
</script><?php /**PATH C:\xampp\htdocs\lentoria-frontend\resources\views\layouts\alert_top.blade.php ENDPATH**/ ?>