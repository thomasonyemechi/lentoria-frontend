<?php

use App\Http\Controllers\JsonFileController;

$app = new JsonFileController;

$app->updateFile();

