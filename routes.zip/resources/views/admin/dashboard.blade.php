@extends('layouts.admin')
@section('page_title')
    Admin Dashboard
@endsection

@section('page_content')

@endsection
